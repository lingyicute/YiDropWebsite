import{_ as o,o as r,c as t,z as s}from"./CLe3daI-.js";const c={};function n(e,a){return r(),t("td",null,[s(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
