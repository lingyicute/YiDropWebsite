import{_ as o,o as r,c as n,r as c}from"./BWsjWLnV.js";const s={};function t(e,a){return r(),n("code",null,[c(e.$slots,"default")])}const _=o(s,[["render",t]]);export{_ as default};
