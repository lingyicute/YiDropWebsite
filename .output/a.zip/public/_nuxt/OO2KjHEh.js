import{_ as r,o,c as t,r as n}from"./B9v-qrTa.js";const s={};function c(e,a){return o(),t("strong",null,[n(e.$slots,"default")])}const _=r(s,[["render",c]]);export{_ as default};
