import"./CT0WSSIN.js";const r=""+new URL("logo-512.QxRaHRJG.png",import.meta.url).href;export{r as _};
