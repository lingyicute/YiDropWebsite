import{e as n,G as e}from"./CxvTveJx.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
