import{_ as r,o,c as t,r as s}from"./B9v-qrTa.js";const a={};function c(e,n){return o(),t("table",null,[s(e.$slots,"default")])}const _=r(a,[["render",c]]);export{_ as default};
