import{_ as r,o,c as t,r as s}from"./BWsjWLnV.js";const a={};function c(e,n){return o(),t("thead",null,[s(e.$slots,"default")])}const _=r(a,[["render",c]]);export{_ as default};
