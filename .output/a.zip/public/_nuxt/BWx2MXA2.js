import{_ as r,o,c as t,r as s}from"./BWsjWLnV.js";const c={};function n(e,a){return o(),t("th",null,[s(e.$slots,"default")])}const _=r(c,[["render",n]]);export{_ as default};
