import{_ as r,o,c as s,r as t}from"./CxvTveJx.js";const c={};function n(e,a){return o(),s("li",null,[t(e.$slots,"default")])}const _=r(c,[["render",n]]);export{_ as default};
