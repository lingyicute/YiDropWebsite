import{_ as o,o as r,c as t,y as s}from"./CA0A7i-q.js";const c={};function n(e,a){return r(),t("th",null,[s(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
