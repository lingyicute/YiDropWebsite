import{_ as r,o,c as t,r as s}from"./B9v-qrTa.js";const c={};function n(e,a){return o(),t("td",null,[s(e.$slots,"default")])}const _=r(c,[["render",n]]);export{_ as default};
