import{_ as o,o as r,c as s,y as t}from"./CA0A7i-q.js";const c={};function n(e,a){return r(),s("li",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
