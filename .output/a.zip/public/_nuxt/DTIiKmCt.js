import{_ as o,o as r,c as t,y as n}from"./CA0A7i-q.js";const s={};function c(e,a){return r(),t("strong",null,[n(e.$slots,"default")])}const _=o(s,[["render",c]]);export{_ as default};
