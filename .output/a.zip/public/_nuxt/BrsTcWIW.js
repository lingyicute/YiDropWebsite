import{_ as o,o as r,c as t,r as c}from"./BWsjWLnV.js";const s={};function n(e,l){return r(),t("blockquote",null,[c(e.$slots,"default")])}const _=o(s,[["render",n]]);export{_ as default};
