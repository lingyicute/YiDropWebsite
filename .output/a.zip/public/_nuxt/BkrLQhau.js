import{f as n,I as e}from"./CA0A7i-q.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
