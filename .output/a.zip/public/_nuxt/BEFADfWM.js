import{e as n,H as e}from"./BWsjWLnV.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
