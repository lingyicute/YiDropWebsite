import{e as n,G as e}from"./B9v-qrTa.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
