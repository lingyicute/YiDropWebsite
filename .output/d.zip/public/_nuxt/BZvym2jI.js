import"./C128amZB.js";const r=""+new URL("logo-512.aU8Z13Dx.png",import.meta.url).href;export{r as _};
