import"./7iU6E5Xm.js";const r=""+new URL("logo-512.QxRaHRJG.png",import.meta.url).href;export{r as _};
